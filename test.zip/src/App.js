import "./App.css";
import Multstep from "./MultiStepForm";

function App() {
  return (
    <div className="App">
      <Multstep />
    </div>
  );
}

export default App;
